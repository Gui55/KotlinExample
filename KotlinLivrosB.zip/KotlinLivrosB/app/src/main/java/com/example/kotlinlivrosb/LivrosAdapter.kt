package com.example.kotlinlivrosb

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import kotlinx.android.synthetic.main.list_item.view.*
import org.jetbrains.annotations.TestOnly

class LivrosAdapter(val lista: List<Livro>, val context: Context) : BaseAdapter() {

    private val listaLivros = lista
    private val contexto = context

    override fun getView(p0: Int, p1: View?, p2: ViewGroup?): View {
        val inflate = LayoutInflater.from(context).inflate(R.layout.list_item, p2, false)

        val livro = listaLivros.get(p0)

        inflate.nomeText.setText(livro.nome)
        inflate.autorText.setText(livro.autor)
        inflate.idText.setText(livro.id.toString())

        return inflate
    }

    override fun getItem(p0: Int): Any {
        return lista.get(p0)
    }

    override fun getItemId(p0: Int): Long {
        return 0
    }

    override fun getCount(): Int {
        return listaLivros.size
    }
}