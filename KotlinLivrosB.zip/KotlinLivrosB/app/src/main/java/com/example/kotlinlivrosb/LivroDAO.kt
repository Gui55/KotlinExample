package com.example.kotlinlivrosb

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface LivroDAO {

    @Query("SELECT * FROM livro")
    fun all(): List<Livro>

    @Insert
    fun insert(vararg livro: Livro)

    @Query("DELETE FROM livro")
    fun apagarTudo()

}