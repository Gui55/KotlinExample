package com.example.kotlinlivrosb

import androidx.room.Database
import androidx.room.RoomDatabase

//ou arrayOf(Livro::class)

@Database(entities = [Livro::class], version = 1, exportSchema = false)
abstract class LivroDatabase : RoomDatabase(){

    public abstract fun livroDao(): LivroDAO
}