package com.example.kotlinlivrosb

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.room.Room
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val database = Room.databaseBuilder(applicationContext, LivroDatabase::class.java, "livroDB")
            .allowMainThreadQueries().build()

        database.livroDao().insert(Livro("Harry Potter e a Pedra Filosofal", "J. K. Rownling"),
            Livro("Divergente", "Veronica Roth"),
            Livro("Jogos Vorazes", "Suzanne Collins"))

        val listaLiv = database.livroDao().all()

        aLista.setAdapter(LivrosAdapter(listaLiv, this))





    }

    override fun onDestroy() {
        super.onDestroy()

    }
}
