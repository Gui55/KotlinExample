package com.example.kotlinlivrosb

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class Livro(val nome: String,
            val autor: String){

    @PrimaryKey(autoGenerate = true) var id: Int = 0

}
