package com.example.kotlinlivrosb

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class Livro(@PrimaryKey(autoGenerate = true) val id: Int,
            @ColumnInfo(name = "Titulo")val nome: String,
            @ColumnInfo(name = "Escritor(a)")val autor: String)
